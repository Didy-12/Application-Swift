import SwiftUI

struct CoursView: View {
    var body: some View {
        // Votre code pour les cours
        Text("Cours")
    }
}
