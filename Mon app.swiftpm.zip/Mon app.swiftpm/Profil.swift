import SwiftUI

struct ProfilView: View {
    var body: some View {
        // Votre code pour le profil
        Text("Profil")
    }
}
